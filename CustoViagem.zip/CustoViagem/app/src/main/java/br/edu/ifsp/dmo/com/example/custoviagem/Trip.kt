package br.edu.ifsp.dmo.com.example.custoviagem

class Trip(var distance: Double, var autonomy : Double, var price : Double ) {

    init {
        if(distance <= 0 || autonomy <= 0 || price <= 0){
            distance = 0.0
            autonomy = 0.0
            price = 0.0
        }
    }

    fun getLiters(): Double{
        return if (autonomy == 0.0){
                0.0
            } else { distance / autonomy
        }
    }

    fun getTotal() = getLiters()*price
}