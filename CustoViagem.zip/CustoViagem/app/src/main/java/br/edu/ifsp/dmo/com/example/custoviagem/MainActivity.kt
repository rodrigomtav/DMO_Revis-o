package br.edu.ifsp.dmo.com.example.custoviagem

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import br.edu.ifsp.dmo.com.example.custoviagem.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)                              //kotlin view binding
        
        binding.buttonCalculate.setOnClickListener(this)

        }

    override fun onClick(v: View) {
        if (v.id == R.id.button_calculate){
            handleCalculate()
        }
    }

    private fun handleCalculate(){
        val distance = extractDouble(binding.edittextDistance)
        val price = extractDouble(binding.edittextAutonomy)
        val autonomy = extractDouble(binding.edittextAutonomy)
        val trip = Trip(distance, autonomy, price)
        binding.textviewTotalvalue.setText(String.format(getString(R.string.money)+"%.2f", trip.getTotal()))

    }

    private fun extractDouble(view: EditText) : Double {
        val str = view.text.toString()
        return if (str.isEmpty()) {
            Toast.makeText(this, "Valor inválido", Toast.LENGTH_LONG).show()
            0.0
        } else {
            str.toDouble()
        }
    }
}
